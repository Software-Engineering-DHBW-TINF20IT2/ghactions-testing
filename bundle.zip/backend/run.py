# Built at Fri Feb 17 06:06:58 UTC 2023
import sys

print("Running Backend...")
print("Python version is: " + sys.version)

sys.exit(0)

