# Built at Fri Feb 17 06:19:09 UTC 2023
import sys

print("Running Backend...")
print("Python version is: " + sys.version)

sys.exit(0)

